package Login;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class LoginDao {

	
    public static String getDayID() {
        Date date = Calendar.getInstance().getTime();
        SimpleDateFormat dateobject = new SimpleDateFormat("ddMMyyyy");
        return dateobject.format(date);
    }
    
    public static String DateConversion(String getdate) {
        
        SimpleDateFormat dateobject = new SimpleDateFormat("ddMMyyyy");
    	Date datefrom = null;
		try {
			datefrom = dateobject.parse(getdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return dateobject.format(datefrom);
    }
    
	
	public static String ExecWebRequest(String url, int flag) {
		URL yahoo;
		BufferedReader in = null;
		String test = null;
		String test1="";
		try {

			if(flag==1)
			{
				yahoo = new URL(url+"/APIReport.jsp?reportType=cpu&fromTime="+getDayID()+"&toTime="+getDayID());
			}
			else if(flag==2)
			{
				yahoo = new URL(url+"/APIReport.jsp?reportType=memory&fromTime="+getDayID()+"&toTime="+getDayID());
			}
			else if(flag==3)
			{
				yahoo = new URL(url+"/APIReport.jsp?reportType=diskdata&fromTime="+getDayID()+"&toTime="+getDayID());
			}
			else
			{
				yahoo = new URL(url+"/APIReport.jsp?reportType=diskspace&fromTime="+getDayID()+"&toTime="+getDayID());
			}
        URLConnection yc = yahoo.openConnection();
        in = new BufferedReader(
                                new InputStreamReader(
                                yc.getInputStream()));
        int i=0;
        while ((test = in.readLine()) != null) {
        	i++;
        	test1=test1.concat(test);
        	//System.out.println("API Test:"+test1);
        }
        //System.out.println("API:"+i);
        	
        }
		catch (IOException e) {
            System.err.println("Problem in executing web url");
        }
		return test1;
	}
	
}
