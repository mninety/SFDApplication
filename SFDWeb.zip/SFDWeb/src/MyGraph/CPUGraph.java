package MyGraph;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import DBManager.DBActivity;
import Login.LoginDao;

public class CPUGraph {

	
	   public static JFreeChart CPUGraph1() {
		      //super(applicationTitle);
		      JFreeChart lineChart = ChartFactory.createLineChart(
		    	 "CPU vs Hour",
		         "Hour","CPU Usage",
		         MysqlConnectionAction(),
		         PlotOrientation.VERTICAL,
		         true,true,false);
		         
		      //ChartPanel chartPanel = new ChartPanel( lineChart );
		      //chartPanel.setPreferredSize( new java.awt.Dimension( 560 , 367 ) );
		      //setContentPane( chartPanel );
		      //setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		      
		    return lineChart;

		   }
	   
	   
		public static DefaultCategoryDataset MysqlConnectionAction()
		{
			DefaultCategoryDataset dataset = new DefaultCategoryDataset( );
		    Connection connection = null;
		    java.sql.Statement stmt = null;
		    
		    try {
		    	connection=DBActivity.getConnection();
		    	stmt = connection.createStatement();
		    	
		    	
		        Statement statement = connection.createStatement( );
		        ResultSet resultSet = statement.executeQuery("select cdValue,cdTime from cpudata where cdDayID='"+LoginDao.getDayID()+"'" );
		        
		        String test=null;
		        String test1=null;
		        int hr=1;
/*		        int i=0;
		        while( resultSet.next( ) ) {
		        	test=resultSet.getString( "mdValue" );
		        	
		           dataset.addValue(Double.parseDouble(test) , "schools" , );
		        i++;
		        }*/
		        while( resultSet.next( ) ) {
		        	test=resultSet.getString( "cdValue" );
		        	test1=resultSet.getString( "cdTime" );
		        	String[] time = test1.split("\\s");
		           dataset.addValue(Double.parseDouble(test) , "Usage" , time[1]);
		        hr++;
		        }
		        
		        
			    stmt.close();
			    connection.close();
			    
		    	
			} catch (SQLException e) {
			    throw new IllegalStateException("Cannot connect the database!", e);
			}
			return dataset;
		}

	   
}
