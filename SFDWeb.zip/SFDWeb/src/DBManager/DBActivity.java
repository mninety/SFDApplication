package DBManager;

import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class DBActivity {
	public static String ServerIP="";
    public static Connection getConnection() throws SQLException {
    	//this.getClass().getResourceAsStream("/SomeTextFile.txt");
    	Connection conn = null;
        String userDB = "root";
        String pass = "Ninety02#";
        try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(
                "jdbc:mysql://localhost/serverfault", userDB, pass);
        
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return conn;
    }

    public static void IPSaver(String ip) {
    	ServerIP=ip;
    }
    
    public static String getIP() {
    	
    	return ServerIP;
    }
	public String getMD5(String input){
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger number = new BigInteger(1, messageDigest);
            String hashtext = number.toString(16);
            // Now we need to zero pad it if you actually want the full 32 chars.
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
	
    public static String SerialKey()
    {
    	String saltStr="";
    	for(int i=1;i<=5;i++)
    	{
	        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	        StringBuilder salt = new StringBuilder();
	        Random rnd = new Random();
	        while (salt.length() < 5) { // length of the random string.
	            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
	            salt.append(SALTCHARS.charAt(index));
	        }
	        if(i!=5)
	        {
	        	saltStr=saltStr.concat(salt.toString()).concat("-");
	        }
	        else
	        {
	        	saltStr=saltStr.concat(salt.toString());
	        }
	        
    	}
    	System.out.println("String: "+saltStr);
        return saltStr;
    }
    
    public static String RandomOTP()
    {
    	Random rnd = new Random();
    	int n = 100000 + rnd.nextInt(900000);
    	return Integer.toString(n);
    }
    
    public static String longToIp(long ip) {

    	return ((ip >> 24) & 0xFF) + "."
    	+ ((ip >> 16) & 0xFF) + "."
    	+ ((ip >> 8) & 0xFF) + "."
    	+ (ip & 0xFF);

      }
    
    public static long IPtolong(String ip)
    {
    	
    	String[] addrArray = ip.split("\\.");
    	//System.out.println(addrArray.length);
    	long num = 0; 
    	   for (int i = 0; i < addrArray.length; i++) { 
    	     int power = 3 - i; 
    	     num += ((Integer.parseInt(addrArray[i]) * Math.pow(256, power))); 
    	   }
    	   return num;
    }
    
    //String sql="SELECT * FROM cpudata WHERE cdDayID = '19082017'";

	//@SuppressWarnings("null")
	public static String MysqlConnectionAction(String query)
	{
		String columnValue1="";
		String columnValue="";
	    Connection connection = null;
	    java.sql.Statement stmt = null;
	    String[] arraydata = null;
	    int j=0;
	    
	    try {
	    	int i;
	    	connection=getConnection();
	    	stmt = connection.createStatement();
		    ResultSet rs=stmt.executeQuery(query);
		    ResultSetMetaData rsmd = rs.getMetaData();
		    int columnsNumber = rsmd.getColumnCount();
		    //System.out.println("Column: "+columnsNumber);
		    int m=0;
		    while (rs.next()) {
		    	
		        for (i = 1; i <= columnsNumber; i++) {
		            //if (i > 1) System.out.print("\n");
		        	if(columnsNumber==3)
		        	{
			        	if(i==1 || i==2)
			        	{
			            columnValue = rs.getString(i);
			            //arraydata[j+m]=columnValue;
			            //System.out.println("Value: "+columnValue);
			            columnValue1=columnValue1.concat(columnValue+",");
			        	}
			        	else
			        	{
				            columnValue = rs.getString(i);
				            //arraydata[j+m]=columnValue;
				            //String[] MemArray = columnValue.split(".");
				            //+"<html><br /></html>"
				            columnValue1=columnValue1.concat(columnValue+"#");
			        	}
		        	}
		        	else if(columnsNumber==1)
		        	{
		        		columnValue1 = rs.getString(i);
		        	}
		        	else if(columnsNumber==2)
		        	{
			        	if(i==1)
			        	{
			            columnValue = rs.getString(i);
			            //arraydata[j+m]=columnValue;
			            //System.out.println("Value: "+columnValue);
			            columnValue1=columnValue1.concat(columnValue+",");
			        	}
			        	else
			        	{
				            columnValue = rs.getString(i);
				            //arraydata[j+m]=columnValue;
				            //String[] MemArray = columnValue.split(".");
				            //+"<html><br /></html>"
				            columnValue1=columnValue1.concat(columnValue+"#");
			        	}
		        	}
		        	else if(columnsNumber==4)
		        	{
			        	if(i==1 || i==2 || i==3)
			        	{
			            columnValue = rs.getString(i);
			            //arraydata[j+m]=columnValue;
			            columnValue1=columnValue1.concat(columnValue+",");
			        	}
			        	else
			        	{
				            columnValue = rs.getString(i);
				            //arraydata[j+m]=columnValue;
				            //String[] MemArray = columnValue.split(".");
				            columnValue1=columnValue1.concat(columnValue+"#");
			        	}
		        	}
		        	else if(columnsNumber==5)
		        	{
			        	if(i<=4)
			        	{
			            columnValue = rs.getString(i);
			            //arraydata[j+m]=columnValue;
			            columnValue1=columnValue1.concat(columnValue+",");
			        	}
			        	else
			        	{
				            columnValue = rs.getString(i);
				            //arraydata[j+m]=columnValue;
				            //String[] MemArray = columnValue.split(".");
				            columnValue1=columnValue1.concat(columnValue+"#");
			        	}
		        	}
		        	else if(columnsNumber==6)
		        	{
			        	if(i<=5)
			        	{
			            columnValue = rs.getString(i);
			            //arraydata[j+m]=columnValue;
			            columnValue1=columnValue1.concat(columnValue+",");
			        	}
			        	else
			        	{
				            columnValue = rs.getString(i);
				            //arraydata[j+m]=columnValue;
				            //String[] MemArray = columnValue.split(".");
				            columnValue1=columnValue1.concat(columnValue+"#");
			        	}
		        	}
		        	m++;
		        }
		        i=1;
		        m=0;
/*			    if(columnsNumber==2)
			    {
			    	j=j+2;
			    }
			    else
			    {
			    	j=j+3;
			    }*/
			    
		    }
	        
	        //System.out.println("Output: "+columnValue1);
		    stmt.close();
		    connection.close();
		} catch (SQLException e) {
		    throw new IllegalStateException("Cannot connect the database!", e);
		}
	    return columnValue1;
	}
	
	public static void MysqlInsertData(String query)
	{
	    Connection conn = null;
	    java.sql.Statement stmt = null;
	    try {
	    	conn=getConnection();


	        // STEP 5: Excute query
	        //System.out.print("\nInserting records into table...");
	        stmt = conn.createStatement();
	        
	        stmt.executeUpdate(query);

	        //System.out.println(" SUCCESS!\n");

	    } catch(SQLException se) {
	        se.printStackTrace();
	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        try {
	            if(stmt != null)
	                conn.close();
	        } catch(SQLException se) {
	        }
	        try {
	            if(conn != null)
	                conn.close();
	        } catch(SQLException se) {
	            se.printStackTrace();
	        }
	    }
	    //System.out.println("Thank you for your patronage!");
	    
	}
	public static void OTPmail(String user, String email)
	{
		String sql="SELECT otOTPToken from otptoken where otFor = '"+user+"' and otOTPToken>0";
		String otp=MysqlConnectionAction(sql);
		//System.out.println("OTP: "+otp);
		if(!otp.equals(""))
		{
			String message="Dear "+user+",<br>Your login OTP Token is: "+otp+"<br>Thanks<br>SMT Team";
			Mail(email, "Login OTP Token", message);
			
/* 			String sql2="UPDATE otptoken set otOTPToken=-"+otp+" where otFor = '"+LogArray[0]+"'";
			DBActivity.MysqlInsertData(sql2); */
		}
		else if(otp.equals(""))
		{
			String otp1=RandomOTP();
			//System.out.println("OTP1: "+otp1);
			String sql3="INSERT INTO otptoken (otFor,otExpireDate,otOTPToken) VALUES ('"+user+"','" + expiretime() + "'," + otp1 + ")";
			MysqlInsertData(sql3);
			
			String message="Dear "+user+",<br><br>Your login OTP Token is: "+otp1+"<br><br>Thanks<br>SMT Team";
			Mail(email, "Login OTP Token", message);
		}
	}
	
	public static void signupOTPmail(String user, String email)
	{

			String otp1=RandomOTP();
			//System.out.println("OTP1: "+otp1);
			String sql3="INSERT INTO otptoken (otFor,otExpireDate,otOTPToken) VALUES ('"+user+"','" + expiretime() + "'," + otp1 + ")";
			MysqlInsertData(sql3);
			
			String message="Dear "+user+",<br><br>Your Signup OTP Token is: "+otp1+"<br><br>Thanks<br>SMT Team";
			Mail(email, "Signup OTP Token", message);
		
	}
	
    public static String expiredate(String flag)
    {
    	DateFormat dateFormat= new SimpleDateFormat("dd/MM/yyyy");

    	Calendar c = Calendar.getInstance();
    	if(flag.equals("1"))
    	{
    		c.add(Calendar.DATE, 365); // 1 year
    	}
    	else if(flag.equals("2"))
    	{
    		c.add(Calendar.DATE, 730); // 2 year
    	}
    	else if(flag.equals("3"))
    	{
    		c.add(Calendar.DATE, 1825); // 5 year
    	}
    	else if(flag.equals("4"))
    	{
    		c.add(Calendar.DATE, 182); // 6 month
    	}
    	else
    	{
    		c.add(Calendar.DATE, 7); // 7 days
    	}
    	String date = dateFormat.format(c.getTime());
    	Date date1 = null;
		try {
			date1 = dateFormat.parse(date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	System.out.println(date1);
    	long unixTime = (long)date1.getTime();
    	System.out.println(unixTime);
    	return Long.toString(unixTime);
    }
    
    public static String expiretime() {
    	Calendar date = Calendar.getInstance();
    	long t= date.getTimeInMillis();
    	Date afterAddingTenMins=new Date(t + (3 * 60000));
    	long unixTime = (long)afterAddingTenMins.getTime();
    	//System.out.println("After Date: "+unixTime);
    	return Long.toString(unixTime);
    }
	public static String JSON(String query,String arrayname)
	{
		String json="[[";
/*		if(arrayname.equals("cpudata"))
		{
			json=json.concat("{{\""+arrayname+"\":\n[");
		}
		else if(arrayname.equals("memorydata"))
		{
			json=json.concat("{{\""+arrayname+"\":\n[");
		}
		else if(arrayname.equals("diskdata"))
		{
			json=json.concat("{{\""+arrayname+"\":\n[");
		}
		else if(arrayname.equals("diskspace"))
		{
			json=json.concat("{{\""+arrayname+"\":\n[");
		}*/
		InputStream is = new ByteArrayInputStream(query.getBytes());
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		int i=1;
		String test="";
			try {
				while((test = br.readLine()) != null)
				{
					json=json.concat("{\n\t\"value\": ");
					
					String[] CPUArray = test.split(",");
					if(arrayname.equals("diskdata"))
					{
						json=json.concat("\""+CPUArray[0]+"\",\n\t"+"\"type\": \""+CPUArray[1]+"\",\n\t"+"\"time\": \""+CPUArray[2]+"\"\n},");
					}
					else
					{
						json=json.concat("\""+CPUArray[0]+"\",\n\t"+"\"time\": \""+CPUArray[1]+"\"\n},");
					}
					
				}
				json=json.substring(1, json.length()-1).concat("]");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
				
		return json;
	}
	
	public static String readVariable(String var)
	{
		int flag=0;
		int gotvar=0;
		Character ch = new Character('a');
		StringBuilder Test = new StringBuilder("");
		StringBuilder tempvar = new StringBuilder("");
		String path = "DB.txt";
		int data;
		try {
			

			Reader fileReader = new FileReader(path);
			data = fileReader.read();
			while(data != -1) {
				ch=(char)data;
				//System.out.println("String: "+ch+flag+gotvar);
				if(flag==0 && ch!='=') {
					Test.append(ch);
				}
				else if(flag==1 && gotvar==1) {
					if(ch!='=' && ch!=';') {
						tempvar.append(ch);
						
					}
				}
				if(ch=='\n') {
					flag=0;
					Test = new StringBuilder("");
				}
				else if(ch=='='){
					flag=1;
					String Test1=Test.toString();
					//System.out.println("Flag:"+Test1);
					//System.out.println("Actual:"+var);
					if(Test1.equals(var))
					{
						//System.out.println("Match Equal"+Test);
						gotvar=1;
					}
				}
				else if(ch==';' && gotvar==1) {
					//System.out.println("Variable Found:"+tempvar);
					break;
				}

				data = fileReader.read();
			  //System.out.println((char)data);
			}
			//String tempvar1=tempvar.toString();
			
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tempvar.toString();
	}
	
	public static void Mail(String toAddress, String subject, String message)
	{
	    try{

	        Properties props = new Properties();
	        props.put("mail.smtp.host", "smtp.gmail.com"); // for gmail use smtp.gmail.com
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.debug", "true"); 
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.port", 465);
	        props.put("mail.smtp.socketFactory.port", 465);
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
	        props.put("mail.smtp.socketFactory.fallback", "false");

	        Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {

	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication("revesqa@gmail.com", "Ninety02#");
	            }
	        });

	        mailSession.setDebug(true); // Enable the debug mode

	        Message msg = new MimeMessage( mailSession );

	        //--[ Set the FROM, TO, DATE and SUBJECT fields
	        msg.setFrom( new InternetAddress( "revesqa@gmail.com" ) );
	        msg.setRecipients( Message.RecipientType.TO,InternetAddress.parse(toAddress) );
	        msg.setSentDate( new Date());
	        msg.setSubject( subject );

	        //--[ Create the body of the mail
	        msg.setText( message );

	        
	        // creates message part
	        MimeBodyPart messageBodyPart = new MimeBodyPart();
	        messageBodyPart.setContent(message, "text/html");
	        
	        // creates multi-part
	        Multipart multipart = new MimeMultipart();
	        multipart.addBodyPart(messageBodyPart);
	        
	        // adds attachments
	 
	        // sets the multi-part as e-mail's content
	        msg.setContent(multipart);
	        
	        //--[ Ask the Transport class to send our mail message
	        Transport.send( msg );

	    }catch(Exception E){
	        System.out.println( "Oops something has gone pearshaped!");
	        System.out.println( E );
	    }
	}
	
}
